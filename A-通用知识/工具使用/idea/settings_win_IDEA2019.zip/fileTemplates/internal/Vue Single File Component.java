/*
 * Created by IntelliJ IDEA.
 * User: ${USER}
 * Date: ${DATE}
 * Time: ${TIME}
 */
package ${PACKAGE_NAME};
public vue single file component ${NAME} { }